<?php session_start();
	 require_once 'config.php';	

	
// definriir les variables  
	$erreur_email = $erreur_password = "";

	if($_SERVER["REQUEST_METHOD"] == "POST"){


		//________________________ Verifier l'@ mail         __________________________ 
		
		if (empty(trim($_POST['Email']))) 
			$erreur_email = "Entrez votre mail"; 
			
			else
				$email = trim($_POST['Email']);
		// _________________________ Verficiatio de password ________________________ 
	
		if(empty(trim($_POST['Password'])))
			$erreur_password = " Entrez votre password";

			else
				$password = $_POST['Password'];

		// __________________________ verfier nos entrées avec les données de BDD ___

		if(!empty($email) and !empty($password)){

			$requete = "SELECT * FROM  users WHERE email='".$email."'";
			$stmt = $connexionBDD->query($requete);
			/*$stmt->exexute();
			$count = $stmt->fetchcolumn();*/

			while($row=$stmt->fetch()){
				$ident= $row["id"];
				$userName= $row["username"];
				$emAil= $row["email"];
				$passworD = $row["password"];
			}
			if($password = $row['password']){
				session_start()
				$_SESSION['id'] = $ident;
				$_SESSION['username'] = $userName;
				$_SESSION['email'] = $emAil;
				// $_SESSION['password'] = $passworD;
				header("Location:profile.php");	
			}
		}else
				echo "email ou mdp incorrect";
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Connexion</title>
		<link rel="stylesheet" type="text/css" href="CSS/bootstrap.min.css">
	</head>

	<body>
		<br>
		<div class="container">
			<div class="row">
				<div class="col"></div>
				<div class="card col" >
				  	<div class="card-body">
				  		<h5 class="card-title">Connexion :</h5>
				    		<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"> 

								<div class="col-12">
									<div class="col-md-12">
								   	<label for="inputEmail4" class="form-label">Email</label>
								    	<input type="email" class="form-control" id="inputEmail4" name="Email"						    	
								    	value="<?php echo (!empty($email))?$email:'';?>"> 
								    	<?php 
								    		echo (!empty($erreur_email))?"<span style='font-size: 13px;color: red;'>".$erreur_email."</span>":"";
								    	?>
								  	</div>
								</div>
							 	<div class="col-12">
								  	<div class="col-md-12">
								   	<label for="inputPassword4" class="form-label">Password</label>
								    	<input type="password" class="form-control" id="inputPassword4" name="Password"
								    	value="<?php echo (!empty($password))?$password:'';?>"> 
								    	<?php 
								    		echo (!empty($erreur_password))?"<span style='font-size: 13px;color: red;'>".$erreur_password."</span>":"";
								    	?>
								  	</div> 		
							 	</div>

							  	<div class="col-12"><br>
							    <button type="submit" class="btn btn-primary" name="Connexion" value="Connexion"> Connexion</button>
							  	</div>
							  	<div class="col-12">
							  		<p> si vous n'avez pas un compte&nbsp;&nbsp;<a href="Inscription.php">créer d'ici </a></p>	
							  	</div>
						</form>	
				   </div>
				</div>
				<div class="col"></div>
			</div>
		</div>


	</body>
</html>