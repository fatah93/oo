<?php 
    session_start();
    require_once 'config.php';
    
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Mon profile</title>
        <link rel="stylesheet" type="text/css" href="CSS/bootstrap.min.css">
    </head>
    
    <body>

        <a class="btn btn-primary" href="Deconnexion.php" role="button" style="margin-left:90%">Déconnexion</a>
        <br>
        <div>
        <fieldset  style="border-radius: 8px; margin-left: 25%; width: 50%;">
            
        </fieldset>
        </div>
       <div class="col-6" style="margin-left: 25%;">
              <div class="card">
  <div class="card-header">
    Mes informationsss
  </div>
  <div class="card-body">
    
            <h4>Username : <?php echo htmlspecialchars($_SESSION['username']);?></h4>
            <h4>Mail : <?php echo htmlspecialchars($_SESSION['email']);?></h4>
    <!-- <a href="#" class="btn btn-primary">Go somewhere</a> -->
  </div>
</div>
       </div>
    
    </body>
</html>