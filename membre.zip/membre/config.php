<?php 

	// password =VXpC8ZE3AtgEpHOu
	
		
		$connexionBDD = new pdo("mysql:host=localhost;dbname=Registration","debian-sys-maint","VXpC8ZE3AtgEpHOu");
	
?>