

<?php 

	header("location:Inscription.php");
	
?>