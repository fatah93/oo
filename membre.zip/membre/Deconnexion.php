<?php 

	session_start();

	//detruire la session
	session_unset();

	//______________ 
	session_destroy();

	//__________ 
	header("Location:Login.php");
	exit;

?>