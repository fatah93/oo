<?php 

	// inclure le fichier de cnx a la BDD 
	require_once "config.php";


	// initialiser qlq variables avec 
	$erreur_username = $erreur_mail = $erreur_password = $erreur_Confpassword = "";

	if($_SERVER["REQUEST_METHOD"] == "POST"){// Verfier c la methode est post 

		//__________________________ validation de username _________________________________@

		if(empty(trim($_POST['Username']))) // verfier si username est vide
			$erreur_username = "entrez username s'il vous plait";

			elseif (!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST['Username']))) // username contient que les letrres et les chiffres 
				$erreur_username = " username ne peut contenir que les lettres et les chiffres";

				else{
					$stmt = $connexionBDD->prepare("select count(*) from users where username=?");
					$stmt->execute([$_POST['Username']]);
					$count = $stmt->fetchColumn(); 

					if($count>=1)// si egale a 1 veut dire username exisssssssssssst 
						$erreur_username = "Cet username exist";
						else
							$username = trim($_POST['Username']);		
		 		}

 		// _________________________ validation d'@ mail ___________________________________@

      if(empty(trim($_POST['Email']))) // verfier c l'@ mail est vide 
         $erreur_mail = "Entrez l'adreese mail s'il vous plait";
            
         elseif (!preg_match('/^[a-zA-Z0-9_@.]+$/',trim($_POST['Email'])))
      	   $erreur_mail = "format de mail incorrect .......!";
            else{

            	$stmtmail  = $connexionBDD->prepare("select count(*) from users where email=?");
               $stmtmail->execute([$_POST['Email']]);
               $countN 	 = $stmtmail->fetchColumn();

               if ($countN!=0)
                  $erreur_mail = "cette adresse existeeeeeeeee";
            		else
                    $email = trim($_POST['Email']);
            } 
      
      // _______________________ validation password ____________________________________@

         $pass = $_POST['Password'];
        if(empty(trim($_POST['Password'])))
            $erreur_password = "Veuillez entrez le mot de passe";
            
           /* elseif (!preg_match('#^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W)#',$_POST['Password'])) 
                $erreur_password = " mdp doit contenir des Maj, les Min,les chifrres";
                */
                elseif(strlen(trim($_POST['Password']))<8)
                    $erreur_password = "mdp doit contenir 8 caracteres au minmm";

                    else
                        $password = trim($_POST['Password']);
       
      //_______________________ validation de confirmation de password _________________@

        if(empty(trim($_POST['Confirmer_password'])))
            $erreur_Confpassword = "Veuillez confirmer le mot de passe";
            else{
                $password_confirm = trim($_POST['Confirmer_password']);
                
                if(!empty($password) and $password!=$password_confirm)
                    $erreur_Confpassword = "les mots de passe ne sont pas identique"; 
            }			   

      //______________________ Insertion dans la BDD si y'a pas d'erreur ______________@

        if(empty($erreur_username) and empty($erreur_password) and empty($erreur_mail) and empty($erreur_Confpassword)){

            $requete = "insert into users(username,email,password) values (?,?,?)";
            $stmt = $connexionBDD->prepare($requete);
            $res = $stmt->execute([$username,$email,$password]);
            session_start();
             header("Location:Login.php");
        }

	}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Inscription</title>
		<link rel="stylesheet" type="text/css" href="CSS/bootstrap.min.css">

	</head>

	<body>
		<br>
		<div class="container">
			<div class="row">
				<div class="col"></div>
				<div class="card col" >
				  	<div class="card-body">
				  		<h5 class="card-title text-center">Inscrivez vous :</h5>
				    	<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>"> 

								<div class="col-12">
									<div class="col-md-12">
								   	<label for="inputEmail4" class="form-label">Username</label>
								    	<input type="text" class="form-control <?php echo (!empty($erreur_username))?"is-invalid":"";?>" 
								    			id="inputEmail4" name="Username"
								    			value="<?php echo (!empty($username))?$username:"";?>">
								    	<?php 
								    echo (!empty($erreur_username))?"<span style='font-size: 13px;color: red;'>".$erreur_username."</span>":"";
								    	?>
								  	</div>
								</div>

								<div class="col-12">
									<div class="col-md-12">
								   	<label for="inputEmail4" class="form-label">Email</label>
								    	<input type="email" class="form-control" id="inputEmail4" name="Email"
								    			 value="<?php echo (!empty($email))?$email:"";?>">
								    	<?php 
								    echo (!empty($erreur_mail))?"<span style='font-size: 13px;color: red;'>".$erreur_mail."</span>":"";
								    	?>
								  	</div>
								</div>

							 	<div class="col-12">
								  	<div class="col-md-12">
								   	<label for="inputPassword4" class="form-label">Password</label>
								    	<input type="password" class="form-control" id="inputPassword4" name="Password">
								    	<?php 
								    echo (!empty($erreur_password))?"<span style='font-size: 13px;color: red;'>".$erreur_password."</span>":"";
								    	?>
								  	</div> 		
							 	</div>
								
								<div class="col-12">
								  	<div class="col-md-12">
								   	<label for="inputPassword4" class="form-label">Confirmer password</label>
								    	<input type="password" class="form-control" id="inputPassword4" name="Confirmer_password">
								    	<?php 
								    echo (!empty($erreur_Confpassword))?"<span style='font-size: 13px;color: red;'>".$erreur_Confpassword."</span>":"";
								    	?>
								  	</div> 		
							 	</div>
							  	
							  	<div class="col-12"><br>
							    <button type="submit" class="btn btn-primary " name="Inscrire" value="Inscrire"> Inscrire</button>
							  	</div>
							  
						</form>	

							  	<div class="col-12">
									<p> si vous avez un compte&nbsp;&nbsp; <a href="Login.php">connecter d'ici </a> </p>
							  	</div>
				   </div>
				</div>
				<div class="col">
				</div>
			</div>
		</div>


	</body>
</html>