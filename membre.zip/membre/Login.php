<?php 
	session_start();
	require_once 'config.php';

	if($_SERVER['REQUEST_METHOD']=="POST"){
		
		//________________________ Verifier l'@ mail         __________________________ 
		 
		$email = (!empty(trim($_POST['Email'])))?(trim($_POST['Email'])):"";
		$erreur_email = (empty(trim($_POST['Email'])))?("Entrez l'@ mail"):"";
		
		// _________________________ Verficiatio de password ________________________ 
	
		$password = (!empty(trim($_POST['password'])))?(trim($_POST['password'])):"";
		$erreur_password = (empty(trim($_POST['password'])))?("Entrez le mdp"):"";
		
		// __________________________ recuperer nos données corresp aux entrérs _____
	
		if(empty($erreur_email)) {
			$sql = "SELECT * FROM users WHERE email='".trim($email)."'";
			$req =$connexionBDD->query($sql);
		
			while($row = $req->fetch()){
				$usrnm = $row['username'];
				$passw = $row['password'];
				$emml = $row['email'];
				// echo "<br>id = ".$row['id']."<br>username = ".$row['username']."<br>email".$row['email']."<br>pass: ".$row['password'];
			}

			if(trim($password)==trim($passw)){
				session_start();
				$_SESSION['username']=$usrnm;
				$_SESSION['password']=$passw;
				$_SESSION['email'] = $emml;
				header("Location:profile.php");
			}else{

				$erreur_password ="mot de passe incorrrrrr";
			}

		}
		
	}
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Connexion</title>
		<link rel="stylesheet" type="text/css" href="CSS/bootstrap.min.css">
	</head>

	<body>
		<br>
		<div class="container">
			<div class="row">
				<div class="col"></div>
				<div class="card col" >
				  	<div class="card-body">
				  		<h5 class="card-title">Connexion :</h5>
				    		<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>"> 

								<div class="col-12">
									<div class="col-md-12">
								   		<label for="inputEmail4" class="form-label">Email</label>
								    	<input type="email" class="form-control" id="inputEmail4" name="Email"
								    	value="<?php echo (!empty($email))?$email:'';?>"> 
								    	<?php 
								    		echo (!empty($erreur_email))?"<span style='font-size: 13px;color: red;'>".$erreur_email."</span>":"";
								    	?>
								  	</div>
								</div>
							 	<div class="col-12">
								  	<div class="col-md-12">
								   	<label for="inputPassword4" class="form-label">Password</label>
								    	<input type="password" class="form-control" id="inputPassword4" name="password"value="<?php echo (!empty($password))?$password:'';?>"> 
								    	<?php 
								    		echo (!empty($erreur_password))?"<span style='font-size: 13px;color: red;'>".$erreur_password."</span>":"";
								    	?> 
								    	
								  	</div> 		
							 	</div>

							  	<div class="col-12"><br>
							    <button type="submit" class="btn btn-primary" name="Connexion" value="Connexion"> Connexion</button>
							  	</div>
							  	<div class="col-12">
							  		<p> si vous n'avez pas un compte&nbsp;&nbsp;<a href="Inscription.php">créer d'ici </a></p>	
							  	</div>
						</form>	
				   </div>
				</div>
				<div class="col"></div>
			</div>
		</div>


	</body>
</html>
